package org.blog.model;

public class PostReview {

}
