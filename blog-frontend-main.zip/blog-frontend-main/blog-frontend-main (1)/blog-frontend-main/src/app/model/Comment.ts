export class Comment
{
    commentId:any;
    content:any;

    constructor(commentId:any,content:any)
    {
        this.commentId=commentId;
        this.content=content;
    }
}